import { useMemo, useState } from 'react'
import {
  LayoutDashboard, Store, Package, ShoppingBag, Users, CreditCard,
  Truck, TicketPercent, ChartNoAxesCombined, Palette, Settings, Globe,
  Bell, Search, Menu, X, Plus, ArrowUpRight, ArrowDownRight, MoreHorizontal,
  ChevronDown, CircleHelp, LogOut, ShieldCheck, Image, Languages, Save,
  Eye, Pencil, Trash2, CheckCircle2, Clock3, Wallet, ShoppingCart
} from 'lucide-react'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid
} from 'recharts'

type Section = 'Dashboard' | 'Store Settings' | 'Products' | 'Orders' | 'Sellers' | 'Customers' | 'Payments' | 'Delivery' | 'Coupons' | 'Reports' | 'Website Design' | 'Homepage Builder' | 'General Settings'

const chartData = [
  { day: 'Sat', sales: 1200 }, { day: 'Sun', sales: 2100 },
  { day: 'Mon', sales: 1700 }, { day: 'Tue', sales: 2800 },
  { day: 'Wed', sales: 2300 }, { day: 'Thu', sales: 3500 },
  { day: 'Fri', sales: 3100 }
]

const initialProducts = [
  { name: 'Premium Honey Nut', sku: 'MHN-001', price: '৳ 850', stock: 24, status: 'Active' },
  { name: 'Mini Gift Box', sku: 'MHN-002', price: '৳ 450', stock: 12, status: 'Active' },
  { name: 'Family Combo Pack', sku: 'MHN-003', price: '৳ 1,250', stock: 0, status: 'Out of stock' }
]

const menu: { label: Section; icon: any; group: string }[] = [
  { label: 'Dashboard', icon: LayoutDashboard, group: 'MAIN MENU' },
  { label: 'Store Settings', icon: Store, group: 'STORE MANAGEMENT' },
  { label: 'Products', icon: Package, group: 'STORE MANAGEMENT' },
  { label: 'Orders', icon: ShoppingBag, group: 'STORE MANAGEMENT' },
  { label: 'Sellers', icon: Users, group: 'PLATFORM MANAGEMENT' },
  { label: 'Customers', icon: Users, group: 'PLATFORM MANAGEMENT' },
  { label: 'Payments', icon: CreditCard, group: 'PLATFORM MANAGEMENT' },
  { label: 'Delivery', icon: Truck, group: 'PLATFORM MANAGEMENT' },
  { label: 'Coupons', icon: TicketPercent, group: 'PLATFORM MANAGEMENT' },
  { label: 'Reports', icon: ChartNoAxesCombined, group: 'ANALYTICS' },
  { label: 'Website Design', icon: Palette, group: 'WEBSITE CONTROL' },
  { label: 'Homepage Builder', icon: Image, group: 'WEBSITE CONTROL' },
  { label: 'General Settings', icon: Settings, group: 'WEBSITE CONTROL' }
]

function App() {
  const [active, setActive] = useState<Section>('Dashboard')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [language, setLanguage] = useState('বাংলা + English')
  const [storeName, setStoreName] = useState('MINI HONEY NUT')
  const [tagline, setTagline] = useState('আপনার পছন্দের অনলাইন শপ')
  const [primary, setPrimary] = useState('#F59E0B')
  const [saved, setSaved] = useState(false)
  const [products, setProducts] = useState(initialProducts)
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [newProduct, setNewProduct] = useState({ name: '', price: '', stock: '1' })

  const filteredProducts = useMemo(
    () => products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase())),
    [products, search]
  )

  const addProduct = () => {
    if (!newProduct.name.trim() || !newProduct.price.trim()) return
    setProducts([...products, {
      name: newProduct.name,
      sku: `MHN-${String(products.length + 1).padStart(3, '0')}`,
      price: `৳ ${newProduct.price}`,
      stock: Number(newProduct.stock) || 0,
      status: Number(newProduct.stock) > 0 ? 'Active' : 'Out of stock'
    }])
    setNewProduct({ name: '', price: '', stock: '1' })
    setShowAdd(false)
  }

  const saveSettings = () => {
    localStorage.setItem('mhn-store-name', storeName)
    localStorage.setItem('mhn-tagline', tagline)
    localStorage.setItem('mhn-primary', primary)
    localStorage.setItem('mhn-language', language)
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const sidebar = (
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="brand">
        <div className="brand-mark">MH</div>
        <div><strong>MINI HONEY NUT</strong><small>Store Management</small></div>
        <button className="mobile-close icon-button" onClick={() => setMobileOpen(false)}><X size={19}/></button>
      </div>
      <div className="profile">
        <div className="avatar">A</div>
        <div className="profile-copy"><strong>Admin Owner</strong><small><span className="online-dot"/> Super Admin</small></div>
        <ChevronDown size={16} className="muted"/>
      </div>
      <nav className="navigation">
        {['MAIN MENU','STORE MANAGEMENT','PLATFORM MANAGEMENT','ANALYTICS','WEBSITE CONTROL'].map(group => (
          <div className="nav-group" key={group}>
            <div className="nav-heading">{group}</div>
            {menu.filter(item => item.group === group).map(item => {
              const Icon = item.icon
              return <button key={item.label} className={`nav-link ${active === item.label ? 'active' : ''}`} onClick={() => { setActive(item.label); setMobileOpen(false) }}>
                <Icon size={18}/><span>{item.label}</span>{active === item.label && <span className="active-indicator"/>}
              </button>
            })}
          </div>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><CircleHelp size={19}/><div><b>Need help?</b><small>Visit support center</small></div></div>
        <button className="nav-link logout"><LogOut size={18}/> Logout</button>
        <small className="version">MINI HONEY NUT • v1.0.0</small>
      </div>
    </aside>
  )

  const statCards = [
    { title: 'মোট বিক্রি', value: '৳ ৪৫,৮৫০', change: '+১২.৫%', up: true, icon: Wallet, tone: 'orange' },
    { title: 'Total Orders', value: '১২৮', change: '+৮.২%', up: true, icon: ShoppingBag, tone: 'blue' },
    { title: 'মোট Products', value: '৫৬', change: '+৪.৬%', up: true, icon: Package, tone: 'purple' },
    { title: 'Customers', value: '৩৪২', change: '-২.১%', up: false, icon: Users, tone: 'green' }
  ]

  return (
    <div className="app-shell" style={{ '--brand': primary } as React.CSSProperties}>
      {sidebar}
      {mobileOpen && <button className="scrim" aria-label="Close menu" onClick={() => setMobileOpen(false)}/>}
      <main className="main-area">
        <header className="topbar">
          <button className="icon-button menu-toggle" onClick={() => setMobileOpen(true)}><Menu size={21}/></button>
          <div className="breadcrumb">Pages <span>/</span> <b>{active}</b></div>
          <div className="top-actions">
            <label className="search-top"><Search size={17}/><input placeholder="Search anything..." /></label>
            <button className="icon-button notification"><Bell size={19}/><i/></button>
            <button className="language-button" onClick={() => setLanguage(language === 'English' ? 'বাংলা + English' : 'English')}><Languages size={17}/><span>{language}</span><ChevronDown size={14}/></button>
            <div className="top-avatar">A</div>
          </div>
        </header>

        <div className="content">
          <div className="welcome-row">
            <div><div className="eyebrow">THURSDAY, 26 NOVEMBER 2026</div><h1>{active === 'Dashboard' ? 'স্বাগতম, Admin! 👋' : active}</h1><p>আপনার MINI HONEY NUT প্ল্যাটফর্মের সবকিছু এক জায়গা থেকে পরিচালনা করুন।</p></div>
            <button className="primary-button" onClick={() => active === 'Products' ? setShowAdd(true) : setActive('Products')}><Plus size={17}/> {active === 'Products' ? 'Add Product' : 'নতুন Product'}</button>
          </div>

          {active === 'Dashboard' && <>
            <div className="stats-grid">
              {statCards.map((s) => { const Icon = s.icon; return <div className="stat-card" key={s.title}>
                <div className="stat-top"><span>{s.title}</span><div className={`stat-icon ${s.tone}`}><Icon size={19}/></div></div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-foot"><span className={s.up ? 'positive' : 'negative'}>{s.up ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {s.change}</span><span>গত মাসের তুলনায়</span></div>
              </div> })}
            </div>
            <div className="dashboard-grid">
              <section className="panel sales-panel">
                <div className="panel-heading"><div><h3>Sales Overview</h3><p>গত ৭ দিনের বিক্রির রিপোর্ট</p></div><button className="select-button">This Week <ChevronDown size={14}/></button></div>
                <div className="chart-legend"><span/><b>Sales</b></div>
                <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData} margin={{top:10,right:10,left:-20,bottom:0}}><defs><linearGradient id="salesFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#F59E0B" stopOpacity={0.24}/><stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef0f3"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill:'#9298a3',fontSize:12}}/><YAxis axisLine={false} tickLine={false} tick={{fill:'#9298a3',fontSize:11}}/><Tooltip formatter={(v) => [`৳ ${v}`, 'Sales']}/><Area type="monotone" dataKey="sales" stroke="#F59E0B" strokeWidth={3} fill="url(#salesFill)"/></AreaChart></ResponsiveContainer></div>
              </section>
              <section className="panel quick-panel"><div className="panel-heading"><div><h3>Quick Actions</h3><p>দ্রুত প্রয়োজনীয় কাজ করুন</p></div></div>
                <button onClick={() => setActive('Products')}><span className="quick-icon orange"><Package size={18}/></span><span><b>পণ্য যোগ করুন</b><small>Add new product</small></span><ArrowUpRight size={16}/></button>
                <button onClick={() => setActive('Orders')}><span className="quick-icon blue"><ShoppingBag size={18}/></span><span><b>অর্ডার দেখুন</b><small>Manage orders</small></span><ArrowUpRight size={16}/></button>
                <button onClick={() => setActive('Store Settings')}><span className="quick-icon purple"><Store size={18}/></span><span><b>স্টোর সেটিংস</b><small>Customize your store</small></span><ArrowUpRight size={16}/></button>
                <button onClick={() => setActive('Website Design')}><span className="quick-icon green"><Palette size={18}/></span><span><b>Website Design</b><small>Brand appearance</small></span><ArrowUpRight size={16}/></button>
              </section>
            </div>
            <section className="panel table-panel"><div className="panel-heading"><div><h3>Recent Orders</h3><p>সর্বশেষ অর্ডারগুলোর তালিকা</p></div><button className="text-button" onClick={() => setActive('Orders')}>সব অর্ডার দেখুন <ArrowUpRight size={15}/></button></div>
              <div className="table-scroll"><table><thead><tr><th>ORDER ID</th><th>CUSTOMER</th><th>DATE</th><th>AMOUNT</th><th>STATUS</th><th/></tr></thead><tbody>
                {[
                  ['#MHN-1024','Rahim Uddin','আজ, ১১:২০ AM','৳ ১,৮৫০','Pending'],
                  ['#MHN-1023','Nusrat Jahan','আজ, ১০:৪৫ AM','৳ ৯৫০','Delivered'],
                  ['#MHN-1022','Karim Hasan','গতকাল','৳ ২,৪৫০','Processing']
                ].map(r => <tr key={r[0]}>{r.map((c,i) => <td key={i}>{i===4?<span className={`status ${c.toLowerCase()}`}>{c}</span>:c}</td>)}<td><button className="icon-button small"><MoreHorizontal size={17}/></button></td></tr>)}
              </tbody></table></div>
            </section>
          </>}

          {active === 'Products' && <section className="panel table-panel"><div className="panel-heading"><div><h3>Product Management</h3><p>আপনার সব পণ্য পরিচালনা করুন</p></div><button className="primary-button" onClick={() => setShowAdd(true)}><Plus size={16}/> Add Product</button></div><div className="toolbar"><label className="search-field"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="পণ্যের নাম বা SKU খুঁজুন..."/></label><span className="muted">{filteredProducts.length} products</span></div><div className="table-scroll"><table><thead><tr><th>PRODUCT</th><th>SKU</th><th>PRICE</th><th>STOCK</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>{filteredProducts.map(p=><tr key={p.sku}><td><b>{p.name}</b></td><td>{p.sku}</td><td>{p.price}</td><td>{p.stock}</td><td><span className={`status ${p.stock>0?'delivered':'pending'}`}>{p.status}</span></td><td><button className="icon-button small"><Pencil size={15}/></button> <button className="icon-button small" onClick={()=>setProducts(products.filter(x=>x.sku!==p.sku))}><Trash2 size={15}/></button></td></tr>)}</tbody></table></div></section>}

          {active === 'General Settings' && <section className="panel settings-panel"><div className="panel-heading"><div><h3>General Website Settings</h3><p>ওয়েবসাইটের মূল তথ্য পরিবর্তন করুন</p></div><span className="settings-badge"><ShieldCheck size={15}/> Super Admin</span></div><div className="form-grid"><label>Website Name<input value={storeName} onChange={e=>setStoreName(e.target.value)}/></label><label>Tagline<input value={tagline} onChange={e=>setTagline(e.target.value)}/></label><label>Contact Email<input placeholder="hello@minihoneynut.com"/></label><label>Phone Number<input placeholder="+880 1XXXXXXXXX"/></label><label>WhatsApp Number<input placeholder="+880 1XXXXXXXXX"/></label><label>Website URL<input placeholder="https://example.com"/></label><label>Default Language<select value={language} onChange={e=>setLanguage(e.target.value)}><option>বাংলা + English</option><option>বাংলা</option><option>English</option></select></label><label>Currency<select defaultValue="BDT"><option value="BDT">BDT (৳)</option></select></label></div><button className="primary-button save-button" onClick={saveSettings}><Save size={16}/> Save Changes</button>{saved&&<span className="saved-message"><CheckCircle2 size={16}/> Settings saved in this browser preview.</span>}</section>}

          {active === 'Website Design' && <section className="panel settings-panel"><div className="panel-heading"><div><h3>Website Appearance</h3><p>আপনার ব্র্যান্ডের রং ও ডিজাইন কাস্টমাইজ করুন</p></div><Palette color="#F59E0B"/></div><div className="form-grid"><label>Primary Brand Color<div className="color-input"><input type="color" value={primary} onChange={e=>setPrimary(e.target.value)}/><code>{primary}</code></div></label><label>Secondary Color<div className="color-input"><input type="color" defaultValue="#FFFFFF"/><code>#FFFFFF</code></div></label></div><div className="preview-card"><div className="preview-brand" style={{background:primary}}>MINI HONEY NUT</div><div className="preview-body"><h3>আপনার পছন্দের অনলাইন শপ</h3><p>Orange & White brand preview</p><button style={{background:primary}}>Shop Now</button></div></div><button className="primary-button save-button" onClick={saveSettings}><Save size={16}/> Save Appearance</button>{saved&&<span className="saved-message">Saved in this browser preview.</span>}</section>}

          {active === 'Store Settings' && <section className="panel settings-panel"><div className="panel-heading"><div><h3>Store Settings</h3><p>আপনার অনলাইন স্টোরের তথ্য পরিচালনা করুন</p></div><Store/></div><div className="form-grid"><label>Store Name<input defaultValue="MINI HONEY NUT"/></label><label>Store URL<input defaultValue="yourdomain.com/s/mini-honey-nut"/></label><label>Store Phone<input placeholder="+880"/></label><label>WhatsApp<input placeholder="+880"/></label><label className="full">Store Description<textarea defaultValue="আপনার পছন্দের অনলাইন শপ" rows={3}/></label></div><button className="primary-button save-button" onClick={saveSettings}><Save size={16}/> Save Store Settings</button></section>}

          {!['Dashboard','Products','General Settings','Website Design','Store Settings'].includes(active) && <section className="panel empty-module"><div className="empty-icon"><Settings size={28}/></div><h3>{active}</h3><p>এই মডিউলের UI ও কার্যকারিতা পরবর্তী development phase-এ যুক্ত হবে।</p><span className="status pending">Planned Module</span></section>}
        </div>
        <footer className="footer">© 2026 <b>MINI HONEY NUT</b>. All rights reserved. <span>Made with care in Bangladesh 🇧🇩</span></footer>
      </main>

      {showAdd && <div className="modal-backdrop" onClick={()=>setShowAdd(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><h3>নতুন Product যোগ করুন</h3><p>পণ্যের প্রাথমিক তথ্য দিন</p></div><button className="icon-button" onClick={()=>setShowAdd(false)}><X/></button></div><label>Product Name<input value={newProduct.name} onChange={e=>setNewProduct({...newProduct,name:e.target.value})} placeholder="পণ্যের নাম"/></label><label>Price (BDT)<input value={newProduct.price} onChange={e=>setNewProduct({...newProduct,price:e.target.value})} placeholder="850"/></label><label>Stock Quantity<input type="number" value={newProduct.stock} onChange={e=>setNewProduct({...newProduct,stock:e.target.value})}/></label><button className="primary-button full-button" onClick={addProduct}><Plus size={16}/> Add Product</button></div></div>}
    </div>
  )
}

export default App

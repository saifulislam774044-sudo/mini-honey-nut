# MINI HONEY NUT

A React + TypeScript starter project for a Bangla-English multi-vendor e-commerce store management platform.

## Current starter contents

- Responsive orange-and-white Super Admin dashboard UI
- Dashboard overview and sales chart (sample/demo data)
- Product listing, search, add and delete in local preview state
- Website general settings preview
- Brand color customization preview
- Store settings preview
- Planned navigation for seller, order, payment, delivery and reporting modules
- Firebase client configuration scaffold
- Environment variable template
- Vite build setup

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local URL shown by Vite.

## Build

```bash
npm run build
npm run preview
```

## Firebase setup

1. Create a Firebase project.
2. Register a Web App in Firebase.
3. Enable the authentication providers you intend to use.
4. Create a Firestore database and Firebase Storage bucket.
5. Copy the web app configuration values into `.env`.
6. Do not commit `.env` or any service-account private key.

The current UI is a starter preview. The sample dashboard figures and product records are demo data. Settings and product changes currently remain in browser state/local preview; they are not yet connected to Firestore. Production authentication, role enforcement, Firestore security rules, payment gateway verification, order persistence, and server-side APIs must be implemented and tested before public launch.

## Google AI Studio / GitHub

This project is packaged as a standard Vite React project. Push the extracted folder to a GitHub repository, then use the GitHub import workflow in Google AI Studio if available in your account. Configure Firebase and environment variables separately after import.

## Brand colors

- Orange: `#F59E0B`
- White: `#FFFFFF`
- App background: `#F7F8FA`
- Text: `#20242C`
